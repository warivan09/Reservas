﻿using controlador;
using Modelo.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginBasico2
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void labelMain_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
            ConsultasController obtener = new ConsultasController();
            List<Ciudades> ciudades = obtener.ListaCiudades();
            List<Agencias> agencias = obtener.ListaAgencias();



            foreach (var item in ciudades)
            {
                this.cmbCiudadesOrigen.Items.Add(item.CIUDAD);
                this.cmbCiudadesDestino.Items.Add(item.CIUDAD);
            }

            foreach (var item in agencias)
            {
                this.cmdAgencia.Items.Add(item.DESCRIPCION);                
            }





        }

        private void cmbCiudadesDestino_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            DateTime fechaSalida;
            DateTime fechaVuelta;



            ValidacionesNegocio val = new ValidacionesNegocio();
            ConsultasController obtener = new ConsultasController();

    
            fechaSalida = new DateTime(SltFechaSalida.Value.Year, SltFechaSalida.Value.Month, SltFechaSalida.Value.Day, 0, 0, 0);
            fechaVuelta = new DateTime(sltFechaVuelta.Value.Year, sltFechaVuelta.Value.Month, sltFechaVuelta.Value.Day, 23, 59, 59);

        

            if (string.IsNullOrEmpty(cmbCiudadesOrigen.Text) || string.IsNullOrEmpty(cmbCiudadesDestino.Text))
            {
                MessageBox.Show("Los Campos de Ciudad Origen y Ciudad Destino no pueden estar vacios");
                return;
            }

            if (string.IsNullOrEmpty(this.cmdAgencia.Text))
            {
                MessageBox.Show("La agencia de viajes es obligatoria");
                return;
            }


            string CiudadOrigen = cmbCiudadesOrigen.SelectedItem.ToString();
            string CiudadDestino = cmbCiudadesDestino.SelectedItem.ToString();
            string Agencia = cmdAgencia.SelectedItem.ToString();

            List<Inforeserva> reservas = obtener.ListaReservas(fechaSalida, fechaVuelta, CiudadOrigen, CiudadDestino, Agencia);

            if (reservas.Count() == 0) {
                MessageBox.Show("No se encontraon vuelos con los criterios de busqueda");
            }

            string validador = val.validarParametros(fechaSalida, fechaVuelta, CiudadOrigen, CiudadDestino);

            if (validador != null && validador != string.Empty)
            {
                MessageBox.Show(validador);
                return;
            }
            else {

                this.grTablaReservas.DataSource = reservas;
                
            }

        }

        private void btnReservar_Click(object sender, EventArgs e)
        {
            string idReserva = textBoxIdResH.Text;

            ValidacionesNegocio Val = new ValidacionesNegocio();
            ConsultasController reserva = new ConsultasController();

            string validador = Val.validarReserva(idReserva);

            if (validador != null && validador != string.Empty)
            {
                MessageBox.Show(validador);
                return;
            }
            else
            {
                if (reserva.ReservarVuelo(idReserva))
                {
                    MessageBox.Show("su vuelo ha sido reservado");
                    
                }
                else
                {
                    MessageBox.Show("Error no se pudo realizar la reserva");
                }



            }

        }

        private void grTablaReservas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var rowIndex = e.RowIndex;
            var currentRow = grTablaReservas.Rows[rowIndex];
            textBoxIdResH.Text = grTablaReservas.Rows[rowIndex].Cells[0].Value.ToString();
            
        }


    }
}
