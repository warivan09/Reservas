﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Modelos
{
    public class Ciudades
    {
        public int ID_CIUDAD { get; set; }
        public string CIUDAD { get; set; }
        public bool ACTIVO { get; set; }
    
    }

    

}
