﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Modelos
{
    public class Personas
    {
        public string IDENTIFICACION { get; set; }
        public string NOMBRES { get; set; }
        public string APELLIDOS { get; set; }
        public string LOGIN { get; set; }
        public string CONTRASENNA { get; set; }
        public bool ACTIVO { get; set; }
    }
}
