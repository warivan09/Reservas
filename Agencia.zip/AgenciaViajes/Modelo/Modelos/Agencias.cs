﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Modelos
{
    public class Agencias
    {
        public int AGENCIA_ID { get; set; }
        public string DESCRIPCION { get; set; }      
    }
}
