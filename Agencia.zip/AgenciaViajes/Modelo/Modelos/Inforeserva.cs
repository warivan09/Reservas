﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Modelos
{
    public class Inforeserva
    {

        public int NUMERORESERVA { get; set; }
        public string ORIGEN { get; set; }
        public DateTime FECHA_SALIDA { get; set; }
        public string DESTINO { get; set; }        
        public DateTime FECHA_REGRESO { get; set; }
        public float VALOR { get; set; }
        public string AGENCIA { get; set; }
        public string ESTADO { get; set; }

    }
}
