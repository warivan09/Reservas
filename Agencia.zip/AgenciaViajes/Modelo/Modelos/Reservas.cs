﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo.Modelos
{
    public class Reservas
    {
        public int ID_RESERVA { get; set; }

        public int CIUDAD_ORIGEN_ID { get; set; }

        public DateTime FECHA_SALIDA { get; set; }

        public int ESTADO_ID { get; set; }

        public int CIUDAD_DESTINO_ID { get; set; }

        public DateTime FECHA_REGRESO { get; set; }

        public float VALOR { get; set; }

        public DateTime FECHA_MODIFICACION { get; set; }

        public int AGENCIA_ID { get; set; }
    }
}
