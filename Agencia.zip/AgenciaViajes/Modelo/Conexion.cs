﻿using LinqToDB;
using LinqToDB.Data;
using Modelo.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo
{
    public class Conexion : DataConnection
    {
        public Conexion() : base("ConexionDB") { }

        public ITable<Personas> _Personas => GetTable<Personas>();
        public ITable<Ciudades> _Ciudades => GetTable<Ciudades>();

        public ITable<Agencias> _Agencias => GetTable<Agencias>();

        public ITable<Inforeserva> _inforeserva=> GetTable<Inforeserva>();

        public ITable<Reservas> _Reservas => GetTable<Reservas>();
    }
}