﻿using LinqToDB;
using Modelo;
using Modelo.Modelos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlador
{
    public class ConsultasController
    {
        Conexion conn = new Conexion();
        public List<Ciudades> ListaCiudades() 
        {
            List<Ciudades> ciudades = (from ciudad in conn._Ciudades
                                      where ciudad.ACTIVO == true
                                      select ciudad).ToList();

            return ciudades;

        }


        public List<Agencias> ListaAgencias()
        {
            List<Agencias> agencias = (from agencia in conn._Agencias                                      
                                       select agencia).ToList();
            return agencias;

        }


        public List<Inforeserva> ListaReservas(DateTime fechaSalida, DateTime fechaRegreso, string CiudadOrigen, string CiudadDestino, string Agencia)
        {
          
            List<Inforeserva> reservas = (from reserva in conn._inforeserva
                                          where reserva.FECHA_SALIDA >= fechaSalida
                                          && reserva.FECHA_REGRESO <= fechaRegreso
                                          && reserva.DESTINO == CiudadDestino
                                          && reserva.ORIGEN == CiudadOrigen
                                          && reserva.AGENCIA == Agencia
                                          select reserva).ToList();


            return reservas;

        }


        public bool ReservarVuelo(string Id)
        {
            bool respuesta = false;
            int IDReserva = Convert.ToInt32(Id);

            conn.BeginTransaction();
            try
            {
                conn._Reservas.Where(R => R.ID_RESERVA == IDReserva)
                    .Set(R => R.ESTADO_ID, 1)
                    .Update();

                conn.CommitTransaction();

                respuesta = true;
            }
            catch (Exception)
            {
                conn.RollbackTransaction();

                respuesta = false;
            }

            return respuesta;

        }
    }
}
