﻿using Modelo;
using Modelo.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlador
{
    public class ValidacionesNegocio
    {
        Conexion conn = new Conexion();

        public string validarParametros(DateTime fechaSalida, DateTime fechaRegreso, string CiudadOrigen, string CiudadDestino)
        {
            string validacion = string.Empty;

            try
            {
                
                if (fechaRegreso < fechaSalida)
                {

                    throw new Exception("La fecha de Salida no puede ser menor que la Fecha de Regreso");

                }

                if (CiudadOrigen.Equals(CiudadDestino))
                {

                    throw new Exception("La Ciudad de Origen no puede ser igual que la del destino");

                }

            }
            catch (Exception ex)
            {           
                validacion += ex.Message;
            }

            return validacion;
        }

        public string validarReserva( string idReserva)
        {
            string validacion = string.Empty;

            List<Reservas> validacionEstado = new List<Reservas>();

            List<int> estados = new List<int> { 1, 3, 5 };

            if (!string.IsNullOrEmpty(idReserva))
            {
                int IdentificacionReserva = Convert.ToInt32(idReserva);

                validacionEstado = (from reserva in conn._Reservas
                                                   where reserva.ID_RESERVA == IdentificacionReserva
                                                   && estados.Contains(reserva.ESTADO_ID)
                                                   select reserva).ToList();
            }

                

            try
            {
                if (string.IsNullOrEmpty(idReserva))
                {
                    throw new Exception("No ha seleccionado Una reserva");
                }
                else if(validacionEstado.Count() > 0 )
                {
                    throw new Exception("Esta reserva ya no se encuentra disponible");
                }
            }
            catch (Exception ex)
            {

                validacion += ex.Message;
            }

            return validacion;
        }

    }
}
