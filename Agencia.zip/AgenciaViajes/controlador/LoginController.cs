﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace controlador
{
    public class LoginController
    {
        Conexion conn = new Conexion();

        public bool validarIngreso(TextBox usuario, TextBox contraseña)
        {
            bool respuesta = false;

           
            try
            {
                var sPass = Encripta.GetSHA256(contraseña.Text.Trim());
                

                var ConsultaValidar = from personas in conn._Personas
                                      where personas.LOGIN == usuario.Text
                                      && personas.CONTRASENNA == sPass
                                      && personas.ACTIVO ==true
                                      select personas; 
                
                if (ConsultaValidar.Count() > 0)
                {
                    respuesta = true;
                }
                else
                {
                    respuesta = false;
                }
            }
            catch (Exception ex)
            {
                var MEsaje = ex.Message;
                respuesta = false;
            }

            return respuesta;
        }

    }
}
